summon mannequin ~ ~ ~ {CustomName:[{text:Arqueiro}],CustomNameVisible:0b,hide_description:1b,equipment:{mainhand:{count:1,id:bow}},Health:40,attributes:[{id:max_health,base:40f}],Tags:["AI_arqueiro","special","AI","new"],profile:{texture:"j_items:mannequin/villager_arqueiro"}}
execute as @n[tag=new] run function j_villagers_update:dar_tags

execute as @n[tag=new] store result entity @s attributes[{id:"minecraft:scale"}].base float 0.01 run random value 95..100
scoreboard players set @n[tag=new] j.mob.speed 70
scoreboard players set @n[tag=new] j.cooldown 0

item replace entity @n[tag=new] armor.head with stick[minecraft:item_model="j_items:heads/villager_archer"]
item replace entity @n[tag=new] weapon.mainhand with bow

execute as @n[tag=new] run function j_mobs:dar_id
tag @n[tag=new] remove new

tp @s[type=villager] ~ ~-1000 ~
kill @s[type=villager]
